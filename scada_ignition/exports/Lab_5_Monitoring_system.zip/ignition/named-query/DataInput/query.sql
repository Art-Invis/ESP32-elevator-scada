SELECT 
    t_stamp AS time,
    current_floor,
    requested_floor,
    direction,
    door_status,
    moving
FROM elevator_history
WHERE t_stamp BETWEEN :start AND :end
ORDER BY t_stamp DESC;