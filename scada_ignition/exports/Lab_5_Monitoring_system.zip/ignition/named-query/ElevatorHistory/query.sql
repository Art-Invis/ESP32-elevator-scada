SELECT 
    t_stamp AS time,
    current_floor,
    requested_floor,
    direction,
    door_status,
    moving
FROM elevator_history
ORDER BY t_stamp DESC
LIMIT 50;